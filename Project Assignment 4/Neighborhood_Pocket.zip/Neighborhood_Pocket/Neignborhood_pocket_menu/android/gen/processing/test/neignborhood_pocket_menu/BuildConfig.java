/** Automatically generated file. DO NOT MODIFY */
package processing.test.neignborhood_pocket_menu;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}