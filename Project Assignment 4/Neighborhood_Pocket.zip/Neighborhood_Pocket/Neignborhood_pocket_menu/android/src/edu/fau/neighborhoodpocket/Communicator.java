package edu.fau.neighborhoodpocket;

public interface Communicator {
	public void onDialogMessage(String message);

}
